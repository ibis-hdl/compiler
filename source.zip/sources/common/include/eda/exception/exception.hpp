/*
 * exception.hpp
 *
 *  Created on: 19.03.2017
 *      Author: olaf
 */

#ifndef SOURCES_COMMON_INCLUDE_EDA_EXCEPTION_EXCEPTION_HPP_
#define SOURCES_COMMON_INCLUDE_EDA_EXCEPTION_EXCEPTION_HPP_


#include <eda/exception/assert_failure.hpp>
#include <eda/exception/range_exception.hpp>


#endif /* SOURCES_COMMON_INCLUDE_EDA_EXCEPTION_EXCEPTION_HPP_ */
