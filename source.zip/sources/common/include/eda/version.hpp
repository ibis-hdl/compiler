/*
 * version.hpp
 *
 *  Created on: 19.03.2017
 *      Author: olaf
 */

#ifndef SOURCES_COMMON_INCLUDE_EDA_VERSION_HPP_
#define SOURCES_COMMON_INCLUDE_EDA_VERSION_HPP_


#define VERSION "a.b.c"


#endif /* SOURCES_COMMON_INCLUDE_EDA_VERSION_HPP_ */
