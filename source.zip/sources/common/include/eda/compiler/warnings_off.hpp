/*
 * compiler_warnings_off.hpp
 *
 *  Created on: 25.06.2018
 *      Author: olaf
 */

#include <eda/compiler/detail/compiler_push.hpp>
#include <eda/compiler/detail/compiler_warning.hpp>
