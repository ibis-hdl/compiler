/*
 * stacktrace_boost.cpp
 *
 *  Created on: 05.08.2018
 *      Author: olaf
 */

#include <boost/stacktrace.hpp>

#include <iostream>




