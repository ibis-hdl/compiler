#include <eda/compiler/warnings_off.hpp>
#include <docopt.cpp>
#include <eda/compiler/warnings_on.hpp>
