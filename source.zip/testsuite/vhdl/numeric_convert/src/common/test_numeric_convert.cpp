/*
 * test_numeric_convert.cpp
 *
 *  Created on: 29.05.2018
 *      Author: olaf
 */

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "VHDL Numeric Conversion Test Suite"
#include <eda/compiler/warnings_off.hpp>
#include <boost/test/included/unit_test.hpp>
#include <eda/compiler/warnings_on.hpp>
