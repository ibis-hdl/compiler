/*
 * dataset-master-test-suite-accessible-main.cpp
 *
 * [#12953 assigned Feature Requests](https://svn.boost.org/trac10/ticket/12953)
 *
 *  Created on: 26.06.2018
 *      Author: olaf
 */


#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "Access master test suite arguments from datasets"
#include <boost/test/included/unit_test.hpp>

